@extends('main')

@section('content')

<div class="row">
	<div class="col-md-4">
		<div class="card">
			<div class="card-header">Login</div>
			<div class="card-body">
				
				@if($message = Session::get('success'))
				<div class="alert alert-success">
				{{ $message }}
				</div>
				@endif
				
				@if($message = Session::get('error'))
				<div class="alert alert-danger">
				{{ $message }}
				</div>
				@endif
			
				<form action="{{ route('sample.validate_login') }}" method="post" autocomplete="off">
					@csrf
					<div class="form-group mb-3">
						<input type="text" name="email" class="form-control" placeholder="Email" />
						@if($errors->has('email'))
							<span class="text-danger">{{ $errors->first('email') }}</span>
						@endif
					</div>
					<div class="form-group mb-3">
						<input type="password" name="password" class="form-control" placeholder="Password" />
						@if($errors->has('password'))
							<span class="text-danger">{{ $errors->first('password') }}</span>
						@endif
					</div>
					<div class="d-grid mx-auto">
						<button type="subit" class="btn btn-primary btn-block">Login</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

@endsection('content')
