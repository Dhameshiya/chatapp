<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chat Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <nav class="navbar navbar-light navbar-expand-lg mb-5" style="background-color: green;">
        <div class="container">
            <a class="navbar-brand mr-auto" href="<?php echo e(route('dashboard')); ?>" style="color: white;">Chat Application</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                    
                <ul class="navbar-nav">
                    <?php if(auth()->guard()->guest()): ?>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('login')); ?>" style="color: white;">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('registration')); ?>" style="color: white;">Register</a>
                    </li>

                    <?php else: ?>
					
					<li class="nav-item">
					<a class="nav-link" href="<?php echo e(route('profile')); ?>" style="color: white;">Welcome &nbsp; <b><?php echo e(Auth::user()->name); ?></b></a>
					</li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('profile')); ?>" style="color: white;">Profile</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>" style="color: white;">Logout</a>
                    </li>

                    <?php endif; ?>
                </ul>
                
            </div>
        </div>
    </nav>
    <div class="container-fluid mt-5">

        <?php echo $__env->yieldContent('content'); ?>
        
    </div>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\chat_app_cyphorex\resources\views/main.blade.php ENDPATH**/ ?>