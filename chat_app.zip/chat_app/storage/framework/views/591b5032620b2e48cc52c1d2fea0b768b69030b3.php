

<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="col-md-4">
		<div class="card">
		<div class="card-header">Registration</div>
		<div class="card-body">
		
			<form action="<?php echo e(route('sample.validate_registration')); ?>" method="POST" autocomplete="off">
				<?php echo csrf_field(); ?>
				<div class="form-group mb-3">
					<input type="text" name="name" class="form-control" placeholder="Enter Name" value="<?php echo e(old('name')); ?>" />
					<?php if($errors->has('name')): ?>
						<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
					<?php endif; ?>
				</div>
				<div class="form-group mb-3">
					<input type="text" name="email" class="form-control" placeholder="Enter Email Address" value="<?php echo e(old('email')); ?>" />
					<?php if($errors->has('email')): ?>
						<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
					<?php endif; ?>
				</div>
				<div class="form-group mb-3">
					<input type="password" name="password" class="form-control" placeholder="Enter Password" />
					<?php if($errors->has('password')): ?>
						<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
					<?php endif; ?>
				</div>
				<div class="d-grid mx-auto">
					<button type="submit" class="btn btn-primary btn-block">Register</button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chat_app\resources\views/registration.blade.php ENDPATH**/ ?>