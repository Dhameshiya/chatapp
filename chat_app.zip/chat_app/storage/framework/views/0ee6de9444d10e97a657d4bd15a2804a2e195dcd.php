

<?php $__env->startSection('content'); ?>

<div class="row justify-content-center">
	<div class="col-md-4">
	
		<div class="card">
			<div class="card-header">Update Profile</div>
			<div class="card-body">
				
				<?php if($message = Session::get('success')): ?>
				<div class="alert alert-success">
				<?php echo e($message); ?>

				</div>
				<?php endif; ?>
			
				<form action="<?php echo e(route('sample.profile_validation')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-group mb-3">
						<input type="text" name="name" class="form-control" placeholder="Name" value="<?php echo e($data->name); ?>" />
						<?php if($errors->has('name')): ?>
							<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
						<?php endif; ?>
					</div>
					<div class="form-group mb-3">
						<input type="text" name="email" class="form-control" placeholder="Email Address" value="<?php echo e($data->email); ?>" />
						<?php if($errors->has('email')): ?>
							<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
						<?php endif; ?>
					</div>
					<div class="form-group mb-3">
						<input type="password" name="password" class="form-control" placeholder="Password" />
						<?php if($errors->has('password')): ?>
							<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
						<?php endif; ?>
					</div>
					<div class="form-group mb-3">
						<input type="file" name="user_image" class="form-control" />
						<?php if($errors->has('user_image')): ?>
							<span class="text-danger"><?php echo e($errors->first('user_image')); ?></span>
						<?php endif; ?>
					</div>
					
					<?php if(isset(Auth::user()->user_image)): ?>
					<div class="form-group mb-3">
						<img src="<?php echo e(asset('images/' . Auth::user()->user_image )); ?>" height="60%" class="rounded-circle" />
					</div>
					<?php endif; ?>
					
					<div class="d-grid mx-auto">
						<button type="subit" class="btn btn-primary btn-block mb-3">Update</button>
						
						<a class="btn btn-dark btn-block" href="<?php echo e(url('dashboard')); ?>">Back</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\chat_app\resources\views/profile.blade.php ENDPATH**/ ?>